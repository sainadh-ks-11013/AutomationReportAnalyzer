/**
 * Automation Failure Intelligence v3.0
 * Deep analysis with Case History comparison & Full Report
 */

(function() {
  'use strict';

  console.log("🔍 Automation Failure Intelligence v3.0 loaded");

  // ============================================
  // CONFIGURATION
  // ============================================

  const CONFIG = {
    panelId: 'afi-analysis-panel',
    debugMode: true
  };

  // ============================================
  // PAGE DETECTION
  // ============================================

  function isReportPage() {
    const url = window.location.href;
    return url.includes("AutomationReports") || 
           url.includes("reportsnew") || 
           url.includes("Qap");
  }

  if (!isReportPage()) {
    console.log("📋 Not a report page - skipping analysis");
    return;
  }

  // ============================================
  // FAILURE PATTERNS DATABASE
  // ============================================

  const AUTOMATION_PATTERNS = {
    elementIssues: {
      patterns: [
        "NoSuchElementException",
        "StaleElementReferenceException",
        "ElementNotInteractableException",
        "ElementClickInterceptedException",
        "element is not present",
        "element is not visible",
        "element is not clickable",
        "element not found",
        "Failed to locate element",
        "Element not Available",
        "Absence Of:",
        "not present after \\d+ seconds"
      ],
      category: "Element Locator Issue",
      suggestion: "Check if element locator is correct or add explicit wait"
    },
    timingIssues: {
      patterns: [
        "TimeoutException",
        "not available after waiting",
        "after waiting \\d+ seconds",
        "Expected condition failed",
        "Timed out waiting"
      ],
      category: "Timing/Wait Issue",
      suggestion: "Increase wait time or use dynamic waits"
    },
    overlayIssues: {
      patterns: [
        "another element.*obscures it",
        "alertFreezeLayer",
        "overlay",
        "modal",
        "is not clickable at point.*because another element"
      ],
      category: "Blocked by Overlay/Popup",
      suggestion: "Handle popup/overlay before interaction"
    },
    setupIssues: {
      patterns: [
        "not configured properly",
        "configuration has started",
        "syncing",
        "precondition",
        "setup failed",
        "DUPLICATE_DATA",
        "already exists",
        // Test data dependency issues
        "associated with other",
        "asscoiated with other",
        "cannot be removed as",
        "can not be removed as",
        "account specific issue",
        "org specific issue",
        "user specific issue",
        // Time slot test issues
        "slot is not found",
        "slots are not found"
      ],
      category: "Test Setup/Data Issue",
      suggestion: "Check test preconditions and data setup"
    },
    // Validation errors - automation provided invalid/empty input
    inputValidationIssues: {
      patterns: [
        "cannot be empty",
        "can't be empty",
        "is required",
        "field is required",
        "this field is required",
        "please enter",
        "please fill",
        "must not be empty",
        "should not be empty",
        "is mandatory",
        "required field",
        "enter a value",
        "enter valid",
        "invalid input",
        "input is invalid",
        "value is required",
        "Name cannot be empty",
        "field cannot be blank",
        "cannot be blank",
        // Special characters / invalid input patterns
        "do not use special characters",
        "special characters not allowed",
        "special characters are not allowed",
        "invalid characters",
        "only alphanumeric",
        "only alphabetic",
        "alphanumeric characters only",
        "no special characters",
        "contains invalid characters",
        "please do not use special characters"
      ],
      category: "Input Validation Error",
      suggestion: "Automation provided invalid test data - check input values"
    },
    // Invalid test data scenarios
    invalidTestDataIssues: {
      patterns: [
        "Validating.*special characters",
        "special characters.*validation",
        "max characters.*validation",
        "Validating.*max characters",
        "character limit",
        "invalid URL",
        "invalid email",
        "invalid phone",
        "invalid format",
        // More validation test patterns
        "invalid domain",
        "Invalid domain name",
        "invalid key",
        "key is invalid",
        "Import.*key.*invalid",
        "duplicate.*symbol",
        "duplicate.*currency",
        "already exists",
        "Please check the domain",
        "check the domain name"
      ],
      category: "Invalid Test Data",
      suggestion: "Test uses intentionally invalid input - expected validation behavior"
    },
    assertionIssues: {
      patterns: [
        "AssertionError",
        "field value is mismatched",
        "expectedAndFoundAreDifferent",
        "Expected.*but found",
        "UnExpected values are found"
      ],
      category: "Assertion Mismatch",
      suggestion: "Verify expected behavior - could be test or product issue"
    }
  };

  const PRODUCT_PATTERNS = {
    serverErrors: {
      patterns: [
        "500 Internal Server Error",
        "502 Bad Gateway",
        "503 Service Unavailable",
        "504 Gateway Timeout",
        "Server Error",
        "ServiceUnavailable"
      ],
      category: "Server/Backend Error",
      severity: "HIGH"
    },
    appExceptions: {
      patterns: [
        "NullPointerException",
        "ArrayIndexOutOfBoundsException",
        "ClassCastException",
        "IllegalStateException",
        "RuntimeException",
        "Exception in thread"
      ],
      category: "Application Exception",
      severity: "HIGH"
    },
    apiErrors: {
      patterns: [
        "API responded with error",
        "API failure",
        "status.*40[0-9]",
        "status.*50[0-9]",
        "Request failed",
        "Failed to fetch"
      ],
      category: "API Error",
      severity: "MEDIUM"
    },
    dbErrors: {
      patterns: [
        "Database error",
        "SQL Exception",
        "Connection refused",
        "DB Connection",
        "Query failed"
      ],
      category: "Database Error",
      severity: "HIGH"
    },
    validationIssues: {
      patterns: [
        "validation.*should.*show.*but.*not",
        "expected.*validation.*error.*not.*display",
        "validation message.*not.*shown",
        "expected.*alert.*but.*not.*present",
        // Negative test - expected error/message not found
        "Expected error msg not found",
        "expected error message not found",
        "Expected error not found",
        "expected validation not found",
        "alert not shown",
        "error message not displayed"
      ],
      category: "Validation Not Triggered",
      severity: "MEDIUM"
    },
    functionalityIssues: {
      patterns: [
        "Sorry, something went wrong",
        "Unexpected error",
        "page crashed",
        "feature not working"
      ],
      category: "Functionality Error",
      severity: "HIGH"
    },
    // Potential product issues - unexpected behavior / incorrect display
    unexpectedBehavior: {
      patterns: [
        "wrongly shown",
        "showing wrongly",
        "is wrong in",
        "content is wrong",
        "value is wrong",
        "showing wrong",
        "not redirecting",
        "redirect failed",
        "is not redirecting",
        "notifications not received",
        "not received when expected",
        "is updating when",
        "updating unexpectedly",
        "unexpectedly updating"
      ],
      category: "Unexpected Behavior",
      severity: "MEDIUM"
    }
  };

  // ============================================
  // ANALYSIS ENGINE
  // ============================================

  function analyzeFailure(text, caseDescription = '') {
    const result = {
      verdict: "NEEDS_REVIEW",
      confidence: 0,
      category: "Unknown",
      matchedPattern: null,
      suggestion: "Manual review required",
      details: [],
      justification: {
        reason: "",
        evidence: [],
        matchedText: "",
        whyThisVerdict: ""
      }
    };

    // PRIORITY CHECK: If case description mentions test data validation scenarios,
    // it's likely an automation issue (testing with invalid input)
    const testDataPatterns = [
      // Special characters / invalid input testing
      /validating.*special characters/i,
      /special characters.*validation/i,
      /validating.*max characters/i,
      /max characters.*validation/i,
      /testing.*invalid.*input/i,
      /invalid.*data.*test/i,
      /boundary.*test/i,
      /negative.*test.*scenario/i,
      // Alert/validation verification scenarios
      /enter.*value.*as.*[!@#$%^&*]/i,
      /enter.*as.*[!@#$%^&*]/i,
      /value.*as.*[!@#$%^&*]/i,
      /domains.*as.*[!@#$%^&*]/i,
      /[!@#$%^&*()]{3,}/i,  // 3+ consecutive special chars in case description
      /check.*alert/i,
      /verify.*alert/i,
      /ensure.*alert/i,
      /alert.*is.*shown/i,
      /alert.*should/i,
      /alert.*throws/i,
      /check.*validation/i,
      /verify.*validation/i,
      /validation.*alert/i,
      /validation.*message/i,
      /check.*error.*message/i,
      /verify.*error.*message/i,
      // VALIDATION MESSAGE VERIFICATION - Row 20 specific patterns
      /verifying.*validation/i,         // "verifying the Validation message"
      /verifying.*the.*validation/i,    // "verifying the Validation"
      /validation.*message.*for/i,      // "Validation message for"
      /validation.*for.*domain/i,       // "validation for domain"
      /allowed.*domain/i,               // "allowed domain input field"
      /domain.*input.*field/i,          // "domain input field"
      /embed.*url.*pop/i,               // "Embed URL pop up"
      /while.*verifying/i,              // "While verifying"
      // Invalid input testing
      /give.*invalid/i,
      /provide.*invalid/i,
      /enter.*invalid/i,
      /invalid.*key/i,
      /invalid.*url/i,
      /invalid.*domain/i,
      /invalid.*email/i,
      /invalid.*phone/i,
      /invalid.*number/i,
      /invalid.*format/i,
      /wrong.*format/i,
      /incorrect.*format/i,
      // Empty/space testing
      /set.*as.*empty/i,
      /provide.*space/i,
      /give.*space/i,
      /space.*alone/i,
      /leave.*blank/i,
      /leave.*empty/i,
      /without.*value/i,
      /no.*value/i,
      // Max limit/boundary testing
      /max.*limit/i,
      /check.*limit/i,
      /exceed.*limit/i,
      /beyond.*limit/i,
      /more.*than.*allowed/i,
      /less.*than.*minimum/i,
      // Negative testing patterns
      /negative.*test/i,
      /edge.*case/i,
      /error.*scenario/i,
      /failure.*scenario/i
    ];

    const hasTestDataScenario = testDataPatterns.some(p => p.test(caseDescription)) || 
                                testDataPatterns.some(p => p.test(text));  // Also check text for patterns
    
    // Debug log for Row 20 investigation
    if (CONFIG.debugMode && (text.includes('allowed domain') || caseDescription.includes('validation message'))) {
      console.log('🔍 DEBUG Row 20:', { 
        caseDescription: caseDescription.substring(0, 200), 
        textSnippet: text.substring(0, 200),
        hasTestDataScenario 
      });
    }
    
    if (hasTestDataScenario) {
      // Check if there's a validation error or element not found in the text
      const automationSignalPatterns = [
        /cannot be empty/i,
        /special characters/i,
        /not.*present after \d+ seconds/i,
        /element is not present/i,
        /element not found/i,
        /invalid.*input/i,
        /is required/i,
        /NoSuchElementException/i,
        /invalid domain/i,
        /invalid key/i,
        /invalid url/i,
        /invalid email/i,
        /invalid phone/i,
        /invalid format/i,
        /button.*not found/i,
        /not found$/i,
        /Alert is shown/i,
        /alert.*presence/i,
        /Due To Presence of.*Alert/i,
        /validation message/i,
        /validating/i,
        /allowed domain/i,
        /embed.*url/i,
        /popup.*not found/i,
        /dialog.*not found/i,
        /modal.*not found/i,
        /error.*message/i,
        /warning.*message/i,
        /field.*error/i,
        /input.*error/i,
        /form.*error/i
      ];
      
      // For test data scenarios with special characters or invalid input,
      // a 400 status is EXPECTED behavior (validation rejection), not a product issue
      const expectedValidationResponses = [
        /status.*400/i,
        /status --400/i,
        /bad request/i,
        /validation.*failed/i,
        /invalid.*request/i,
        /rejected/i
      ];
      
      const hasAutomationSignal = automationSignalPatterns.some(p => p.test(text));
      const hasExpectedValidationResponse = expectedValidationResponses.some(p => p.test(text));
      
      if (hasAutomationSignal || hasExpectedValidationResponse) {
        result.verdict = "AUTOMATION_ISSUE";
        result.confidence = 90;
        result.category = "Invalid Test Data / Validation Test";
        result.matchedPattern = "Test data validation scenario";
        result.suggestion = "Test uses intentionally invalid input for validation testing - expected behavior";
        result.details.push(`Case description indicates validation testing: "${caseDescription.substring(0, 100)}..."`);
        
        // Build justification
        result.justification = {
          reason: "Test is performing INPUT VALIDATION testing with intentionally invalid data",
          evidence: [
            `Case description mentions validation/testing scenario`,
            hasAutomationSignal ? `Automation signal detected in error text` : null,
            hasExpectedValidationResponse ? `400/Bad Request response is EXPECTED when server rejects invalid input` : null,
            `Pattern matched: validation/special characters/invalid input testing`
          ].filter(Boolean),
          matchedText: text.substring(0, 200),
          whyThisVerdict: "When automation sends invalid input (special characters, empty values, wrong formats) to test validation, the application SHOULD reject it. This is the test working correctly - not a product bug. The 'failure' is actually the expected validation behavior being verified."
        };
        
        if (hasExpectedValidationResponse) {
          result.details.push("400 status is expected when server rejects invalid input during validation testing");
        }
        return result;
      }
    }

    // Check product patterns first (higher priority)
    for (const [key, patternGroup] of Object.entries(PRODUCT_PATTERNS)) {
      for (const pattern of patternGroup.patterns) {
        const regex = new RegExp(pattern, 'i');
        if (regex.test(text)) {
          const matchedTextSnippet = text.match(regex)?.[0] || pattern;
          result.verdict = "PRODUCT_ISSUE";
          result.confidence = 85;
          result.category = patternGroup.category;
          result.matchedPattern = pattern;
          result.severity = patternGroup.severity;
          result.details.push(`Found: "${pattern}"`);
          
          // Build justification for Product Issue
          result.justification = {
            reason: `Detected ${patternGroup.category} - indicates a potential product defect`,
            evidence: [
              `Pattern matched: "${pattern}"`,
              `Category: ${patternGroup.category}`,
              `Severity: ${patternGroup.severity}`,
              `This is NOT a test data validation scenario`
            ],
            matchedText: matchedTextSnippet,
            whyThisVerdict: getProductIssueExplanation(key, patternGroup.category)
          };
          
          return result;
        }
      }
    }

    // Check automation patterns
    for (const [key, patternGroup] of Object.entries(AUTOMATION_PATTERNS)) {
      for (const pattern of patternGroup.patterns) {
        const regex = new RegExp(pattern, 'i');
        if (regex.test(text)) {
          const matchedTextSnippet = text.match(regex)?.[0] || pattern;
          result.verdict = "AUTOMATION_ISSUE";
          result.confidence = 80;
          result.category = patternGroup.category;
          result.matchedPattern = pattern;
          result.suggestion = patternGroup.suggestion;
          result.details.push(`Found: "${pattern}"`);
          
          // Build justification for Automation Issue
          result.justification = {
            reason: `Detected ${patternGroup.category} - this is an automation/test infrastructure problem`,
            evidence: [
              `Pattern matched: "${pattern}"`,
              `Category: ${patternGroup.category}`,
              `Suggestion: ${patternGroup.suggestion}`
            ],
            matchedText: matchedTextSnippet,
            whyThisVerdict: getAutomationIssueExplanation(key, patternGroup.category)
          };
          
          return result;
        }
      }
    }

    if (/assertion|mismatch|expected.*actual/i.test(text)) {
      result.verdict = "NEEDS_REVIEW";
      result.confidence = 50;
      result.category = "Assertion Failure";
      result.suggestion = "Compare expected vs actual - could be test or product issue";
      result.justification = {
        reason: "Assertion failure detected - requires manual analysis",
        evidence: [`Text contains assertion/mismatch keywords`],
        matchedText: text.substring(0, 200),
        whyThisVerdict: "Assertion failures can be caused by either test issues (wrong expected values, outdated test data) OR product bugs (actual behavior changed). Manual review of expected vs actual values is needed to determine the root cause."
      };
    } else {
      // Default justification for needs review
      result.justification = {
        reason: "No clear pattern matched - requires manual investigation",
        evidence: [`No automation or product issue patterns detected`],
        matchedText: text.substring(0, 200),
        whyThisVerdict: "This failure doesn't match known automation or product issue patterns. Please review the failure details, DOM snapshot, and video to determine if this is a test infrastructure problem or an actual product bug."
      };
    }

    return result;
  }

  // Explanation generators for justifications
  function getProductIssueExplanation(key, category) {
    const explanations = {
      serverErrors: "Server errors (5xx) indicate backend/infrastructure problems that are NOT caused by the test. The application should handle requests without crashing.",
      appExceptions: "Application exceptions (NullPointer, ArrayIndexOutOfBounds, etc.) indicate bugs in the product code that need to be fixed by developers.",
      apiErrors: "API errors indicate the backend is returning error responses. If the test was sending VALID data, this suggests a product issue.",
      dbErrors: "Database errors indicate backend data layer problems that need developer attention.",
      validationIssues: "Expected validation was NOT triggered when it should have been - the product failed to show the expected error/warning.",
      functionalityIssues: "Core functionality is broken - the product crashed or showed unexpected error messages.",
      unexpectedBehavior: "The product is displaying wrong values or behaving unexpectedly - this indicates a functional bug."
    };
    return explanations[key] || `${category} detected - indicates a product defect that needs developer attention.`;
  }

  function getAutomationIssueExplanation(key, category) {
    const explanations = {
      elementIssues: "Element not found or not interactable - the test locator may be outdated, or the page didn't load properly. Check if the element selector is correct and add waits if needed.",
      timingIssues: "Timeout occurred waiting for element/condition - the page may be slower than expected. Consider increasing wait times or using dynamic waits.",
      overlayIssues: "An overlay/popup is blocking the element - the test needs to handle/dismiss the overlay before proceeding.",
      setupIssues: "Test data or configuration is not set up correctly - check preconditions and test data preparation.",
      inputValidationIssues: "Test provided invalid input and the application correctly rejected it - this is expected behavior for validation testing.",
      invalidTestDataIssues: "Test is verifying validation behavior with intentionally invalid data - the 'failure' is actually the expected validation working correctly.",
      assertionIssues: "Assertion mismatch - verify if the expected values in the test are correct for the current application state."
    };
    return explanations[key] || `${category} detected - this is a test/automation infrastructure issue, not a product bug.`;
  }

  // ============================================
  // DOM EXTRACTION - IMPROVED FOR ALL ROWS
  // ============================================

  function extractAllFailureRows() {
    const failures = [];
    
    // Find all report rows - look for rows with IDs starting with reportrows_
    const reportRows = document.querySelectorAll('[id^="reportrows_"]');
    
    if (reportRows.length > 0) {
      console.log(`📊 Found ${reportRows.length} report rows`);
      
      reportRows.forEach((row, index) => {
        // Extract case name from the row header
        let caseName = '';
        const caseHeader = row.closest('[id^="report_"]') || row.parentElement;
        if (caseHeader) {
          const nameEl = caseHeader.querySelector('div > span, div > div > span');
          if (nameEl) caseName = nameEl.innerText;
        }
        
        // Fallback: try to get from the row itself
        if (!caseName) {
          const firstDiv = row.querySelector('div');
          if (firstDiv) {
            caseName = firstDiv.innerText.split('\n')[0];
          }
        }
        
        // Extract failure and reason text
        const rowText = row.innerText || row.textContent;
        
        let failureText = '';
        let reasonText = '';
        
        // Extract Failure text
        const failureMatch = rowText.match(/Failure\s*[:\-]?\s*([^\n]+)/i);
        if (failureMatch) failureText = failureMatch[1].trim();
        
        // Extract Reason text
        const reasonMatch = rowText.match(/(?:Reason|Due to)\s*[:\-]?\s*([^\n]+)/i);
        if (reasonMatch) reasonText = reasonMatch[1].trim();
        
        // Get ReConstructed DOM link
        const domLink = row.querySelector('a[href*="Failure_DOM"]')?.href || null;
        
        // Get Video links (Failure video, Ideal test case video)
        const videoLinks = extractVideoLinks(row);
        
        // Get Case History menu element
        const caseHistoryMenu = row.querySelector('li');
        
        failures.push({
          index: index + 1,
          rowId: row.id,
          caseName: cleanCaseName(caseName) || `Row ${index + 1}`,
          failureText: failureText,
          reasonText: reasonText,
          fullText: rowText.substring(0, 3000),
          element: row,
          domLink: domLink,
          failureVideoLink: videoLinks.failureVideo,
          idealVideoLink: videoLinks.idealVideo,
          hasCaseHistory: !!caseHistoryMenu
        });
      });
    }

    // Alternative: Find failure containers in different page structures
    if (failures.length === 0) {
      // Try to find rows by class patterns
      const alternateRows = document.querySelectorAll('.failure-row, .test-failure, [class*="breakage"], .row-data');
      alternateRows.forEach((row, index) => {
        const text = row.innerText || row.textContent;
        if (text && text.length > 20) {
          const videoLinks = extractVideoLinks(row);
          failures.push({
            index: index + 1,
            rowId: row.id || `row-${index}`,
            caseName: extractCaseNameFromText(text) || `Case ${index + 1}`,
            failureText: extractFailureFromText(text),
            reasonText: extractReasonFromText(text),
            fullText: text.substring(0, 3000),
            element: row,
            domLink: row.querySelector('a[href*="DOM"]')?.href || null,
            failureVideoLink: videoLinks.failureVideo,
            idealVideoLink: videoLinks.idealVideo,
            hasCaseHistory: false
          });
        }
      });
    }

    console.log(`✅ Extracted ${failures.length} failure rows`);
    return failures;
  }

  // ============================================
  // VIDEO LINK EXTRACTION - For verification
  // ============================================

  function extractVideoLinks(row) {
    const result = {
      failureVideo: null,
      idealVideo: null
    };
    
    // Look for video links in the row
    // Pattern 1: Links with "imageplayer" in href
    const videoAnchors = row.querySelectorAll('a[href*="imageplayer"]');
    
    videoAnchors.forEach(anchor => {
      const text = anchor.innerText.toLowerCase();
      const href = anchor.href;
      
      if (text.includes('failure') || (href && !href.includes('idealtestcaseexecutionvideo'))) {
        result.failureVideo = href;
      }
      if (text.includes('ideal') || (href && href.includes('idealtestcaseexecutionvideo'))) {
        result.idealVideo = href;
      }
    });
    
    // Pattern 2: Look for Video links by text content
    const allAnchors = row.querySelectorAll('a');
    allAnchors.forEach(anchor => {
      const text = anchor.innerText.toLowerCase();
      const href = anchor.href;
      
      if (text.includes('failure video') && !result.failureVideo) {
        result.failureVideo = href;
      }
      if (text.includes('ideal') && text.includes('video') && !result.idealVideo) {
        result.idealVideo = href;
      }
      // Generic "Video" link usually means failure video
      if (text === 'video' && !result.failureVideo) {
        result.failureVideo = href;
      }
    });
    
    return result;
  }

  function cleanCaseName(name) {
    if (!name) return '';
    return name.replace(/TOTAL\s*:\s*\d+/gi, '')
               .replace(/\d+$/g, '')
               .replace(/\n.*/g, '')
               .trim()
               .substring(0, 50);
  }

  function extractCaseNameFromText(text) {
    const lines = text.split('\n');
    return lines[0]?.substring(0, 50) || '';
  }

  function extractFailureFromText(text) {
    const match = text.match(/Failure\s*[:\-]?\s*([^\n]+)/i);
    return match ? match[1].trim() : text.substring(0, 200);
  }

  function extractReasonFromText(text) {
    const match = text.match(/(?:Reason|Due to)\s*[:\-]?\s*([^\n]+)/i);
    return match ? match[1].trim() : '';
  }

  function analyzeAllFailures() {
    const failures = extractAllFailureRows();
    const results = [];

    failures.forEach(failure => {
      const combinedText = `${failure.failureText} ${failure.reasonText} ${failure.fullText}`;
      // Extract case description from fullText for better analysis
      const caseDescMatch = failure.fullText.match(/Case Description\s*:\s*([\s\S]+?)(?=\n\s*\d\.|Additional|API_DETAILS|$)/i);
      const caseDescription = caseDescMatch ? caseDescMatch[1] : '';
      const analysis = analyzeFailure(combinedText, caseDescription);
      results.push({
        ...failure,
        analysis,
        caseDescription: caseDescription.substring(0, 500)
      });
    });

    return results;
  }

  // ============================================
  // UI HELPERS
  // ============================================

  function getVerdictEmoji(verdict) {
    switch(verdict) {
      case 'PRODUCT_ISSUE': return '🔴';
      case 'AUTOMATION_ISSUE': return '🟡';
      case 'NEEDS_REVIEW': return '🔵';
      default: return '⚪';
    }
  }

  function getVerdictLabel(verdict) {
    switch(verdict) {
      case 'PRODUCT_ISSUE': return 'Product Issue';
      case 'AUTOMATION_ISSUE': return 'Automation Issue';
      case 'NEEDS_REVIEW': return 'Needs Review';
      default: return 'Unknown';
    }
  }

  function getVerdictColor(verdict) {
    switch(verdict) {
      case 'PRODUCT_ISSUE': return '#ff4444';
      case 'AUTOMATION_ISSUE': return '#ffbb33';
      case 'NEEDS_REVIEW': return '#33b5e5';
      default: return '#999999';
    }
  }

  function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // ============================================
  // UI PANEL CREATION
  // ============================================

  function createPanel(results) {
    const existingPanel = document.getElementById(CONFIG.panelId);
    if (existingPanel) existingPanel.remove();
    
    const existingBadge = document.getElementById('afi-minimize-badge');
    if (existingBadge) existingBadge.remove();

    const counts = { PRODUCT_ISSUE: 0, AUTOMATION_ISSUE: 0, NEEDS_REVIEW: 0 };
    results.forEach(r => {
      counts[r.analysis.verdict] = (counts[r.analysis.verdict] || 0) + 1;
    });

    let overallVerdict = 'NEEDS_REVIEW';
    if (counts.PRODUCT_ISSUE > 0) overallVerdict = 'PRODUCT_ISSUE';
    else if (counts.AUTOMATION_ISSUE > 0) overallVerdict = 'AUTOMATION_ISSUE';

    const panel = document.createElement('div');
    panel.id = CONFIG.panelId;
    panel.innerHTML = `
      <style>
        #${CONFIG.panelId} {
          position: fixed;
          top: 10px;
          right: 10px;
          width: 380px;
          max-height: 85vh;
          background: #1a1a2e;
          color: #eee;
          border-radius: 12px;
          box-shadow: 0 8px 32px rgba(0,0,0,0.4);
          z-index: 99999;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          font-size: 13px;
          overflow: hidden;
          display: flex;
          flex-direction: column;
        }
        #${CONFIG.panelId} .afi-header {
          background: linear-gradient(135deg, #16213e 0%, #0f3460 100%);
          padding: 14px 16px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          border-bottom: 1px solid #333;
        }
        #${CONFIG.panelId} .afi-title {
          font-weight: 600;
          font-size: 14px;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        #${CONFIG.panelId} .afi-close {
          background: none;
          border: none;
          color: #888;
          font-size: 20px;
          cursor: pointer;
          padding: 0 4px;
        }
        #${CONFIG.panelId} .afi-close:hover { color: #fff; }
        #${CONFIG.panelId} .afi-summary {
          padding: 16px;
          background: ${getVerdictColor(overallVerdict)}22;
          border-bottom: 1px solid #333;
        }
        #${CONFIG.panelId} .afi-verdict {
          font-size: 18px;
          font-weight: 700;
          color: ${getVerdictColor(overallVerdict)};
          margin-bottom: 8px;
        }
        #${CONFIG.panelId} .afi-counts {
          display: flex;
          gap: 12px;
          font-size: 12px;
          margin-bottom: 10px;
        }
        #${CONFIG.panelId} .afi-count { display: flex; align-items: center; gap: 4px; }
        #${CONFIG.panelId} .afi-actions {
          display: flex;
          gap: 8px;
          margin-top: 10px;
        }
        #${CONFIG.panelId} .afi-btn {
          padding: 8px 12px;
          border: none;
          border-radius: 6px;
          cursor: pointer;
          font-size: 12px;
          font-weight: 500;
          transition: all 0.2s;
        }
        #${CONFIG.panelId} .afi-btn-primary {
          background: #4CAF50;
          color: white;
        }
        #${CONFIG.panelId} .afi-btn-primary:hover { background: #45a049; }
        #${CONFIG.panelId} .afi-btn-secondary {
          background: #2196F3;
          color: white;
        }
        #${CONFIG.panelId} .afi-btn-secondary:hover { background: #1976D2; }
        #${CONFIG.panelId} .afi-results {
          flex: 1;
          overflow-y: auto;
          padding: 8px;
        }
        #${CONFIG.panelId} .afi-result {
          background: #16213e;
          border-radius: 8px;
          padding: 12px;
          margin-bottom: 8px;
          border-left: 3px solid;
          cursor: pointer;
          transition: all 0.2s;
        }
        #${CONFIG.panelId} .afi-result:hover {
          background: #1e2a4a;
          transform: translateX(3px);
        }
        #${CONFIG.panelId} .afi-result-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 6px;
        }
        #${CONFIG.panelId} .afi-result-name {
          font-weight: 600;
          font-size: 12px;
          color: #ccc;
          max-width: 200px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        #${CONFIG.panelId} .afi-result-category {
          font-size: 11px;
          color: #888;
          margin-bottom: 4px;
        }
        #${CONFIG.panelId} .afi-result-failure {
          font-size: 11px;
          color: #aaa;
          margin: 6px 0;
          padding: 6px;
          background: #0f1525;
          border-radius: 4px;
          max-height: 60px;
          overflow: hidden;
        }
        #${CONFIG.panelId} .afi-result-actions {
          display: flex;
          gap: 6px;
          margin-top: 8px;
          flex-wrap: wrap;
        }
        #${CONFIG.panelId} .afi-action-btn {
          padding: 4px 8px;
          font-size: 10px;
          background: #2a3a5e;
          border: 1px solid #3a4a6e;
          border-radius: 4px;
          color: #aaa;
          cursor: pointer;
          text-decoration: none;
          display: inline-block;
        }
        #${CONFIG.panelId} .afi-action-btn:hover {
          background: #3a4a6e;
          color: #fff;
        }
        #${CONFIG.panelId} .afi-result-suggestion {
          font-size: 11px;
          color: #6c9;
          margin-top: 6px;
          padding: 6px 8px;
          background: #1a3a2a;
          border-radius: 4px;
        }
        #${CONFIG.panelId} .afi-total {
          font-size: 11px;
          color: #888;
          padding: 8px 12px;
          background: #0f1525;
          text-align: center;
          border-bottom: 1px solid #333;
        }
        .afi-minimize-badge {
          position: fixed;
          top: 10px;
          right: 10px;
          padding: 10px 16px;
          background: ${getVerdictColor(overallVerdict)};
          color: #fff;
          border-radius: 8px;
          cursor: pointer;
          font-weight: 600;
          font-size: 13px;
          z-index: 99998;
          box-shadow: 0 4px 12px rgba(0,0,0,0.3);
          display: none;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        #${CONFIG.panelId} .afi-deep-result {
          margin-top: 8px;
          padding: 8px;
          background: #0a0f1a;
          border-radius: 4px;
          font-size: 10px;
          border-left: 2px solid #4CAF50;
        }
      </style>
      <div class="afi-header">
        <span class="afi-title">🔍 Failure Intelligence v3</span>
        <button class="afi-close" id="afi-minimize-btn">−</button>
      </div>
      <div class="afi-summary">
        <div class="afi-verdict">
          ${getVerdictEmoji(overallVerdict)} ${getVerdictLabel(overallVerdict)}
        </div>
        <div class="afi-counts">
          <span class="afi-count">🔴 ${counts.PRODUCT_ISSUE} Product</span>
          <span class="afi-count">🟡 ${counts.AUTOMATION_ISSUE} Automation</span>
          <span class="afi-count">🔵 ${counts.NEEDS_REVIEW} Review</span>
        </div>
        <div class="afi-actions">
          <button class="afi-btn afi-btn-primary" id="afi-open-full">📊 Full Report</button>
          <button class="afi-btn afi-btn-secondary" id="afi-refresh">🔄 Refresh</button>
        </div>
      </div>
      <div class="afi-total">📋 Total: ${results.length} failure rows (showing all)</div>
      <div class="afi-results" id="afi-results">
        ${results.map((r, i) => createResultCard(r, i)).join('')}
      </div>
    `;

    document.body.appendChild(panel);

    // Add minimize button
    const minimizeBtn = document.createElement('div');
    minimizeBtn.id = 'afi-minimize-badge';
    minimizeBtn.className = 'afi-minimize-badge';
    minimizeBtn.innerHTML = `${getVerdictEmoji(overallVerdict)} ${results.length} Issues`;
    document.body.appendChild(minimizeBtn);

    // Event handlers
    document.getElementById('afi-minimize-btn').addEventListener('click', () => {
      panel.style.display = 'none';
      minimizeBtn.style.display = 'block';
    });

    minimizeBtn.addEventListener('click', () => {
      panel.style.display = 'flex';
      minimizeBtn.style.display = 'none';
    });

    document.getElementById('afi-open-full').addEventListener('click', () => {
      openFullReport(results);
    });

    document.getElementById('afi-refresh').addEventListener('click', () => {
      init();
    });

    // Add click handlers for each result row
    results.forEach((r, i) => {
      const resultEl = document.getElementById(`afi-row-${i}`);
      if (resultEl) {
        // Click to scroll to row
        resultEl.addEventListener('click', (e) => {
          if (e.target.closest('.afi-action-btn')) return;
          if (r.element) {
            r.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
            r.element.style.outline = '3px solid ' + getVerdictColor(r.analysis.verdict);
            r.element.style.outlineOffset = '2px';
            setTimeout(() => { 
              r.element.style.outline = ''; 
              r.element.style.outlineOffset = '';
            }, 3000);
          }
        });
        
        // Deep analyze button
        const analyzeBtn = resultEl.querySelector('.afi-deep-analyze');
        if (analyzeBtn) {
          analyzeBtn.addEventListener('click', async (e) => {
            e.stopPropagation();
            await performDeepAnalysis(r, i);
          });
        }
        
        // View history button
        const historyBtn = resultEl.querySelector('.afi-view-history');
        if (historyBtn) {
          historyBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            openCaseHistory(r);
          });
        }
        
        // Justification button
        const justificationBtn = resultEl.querySelector('.afi-justification-btn');
        if (justificationBtn) {
          justificationBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            showJustificationModal(r, i);
          });
        }
        
        // Playwright MCP prompt button
        const playwrightBtn = resultEl.querySelector('.afi-playwright-btn');
        if (playwrightBtn) {
          playwrightBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            showPlaywrightPromptModal(r, i);
          });
        }
      }
    });

    // Store results globally
    window.AFI_RESULTS = results;
  }

  function createResultCard(r, i) {
    return `
      <div class="afi-result" id="afi-row-${i}" style="border-color: ${getVerdictColor(r.analysis.verdict)}">
        <div class="afi-result-header">
          <span class="afi-result-name" title="${escapeHtml(r.caseName)}">${getVerdictEmoji(r.analysis.verdict)} #${i + 1} ${escapeHtml(r.caseName)}</span>
          <span style="color: ${getVerdictColor(r.analysis.verdict)}; font-size: 11px;">${getVerdictLabel(r.analysis.verdict)}</span>
        </div>
        <div class="afi-result-category">${r.analysis.category}</div>
        ${r.failureText ? `<div class="afi-result-failure">${escapeHtml(r.failureText.substring(0, 150))}${r.failureText.length > 150 ? '...' : ''}</div>` : ''}
        <div style="font-size:10px;color:#666">Confidence: ${r.analysis.confidence}%</div>
        ${r.analysis.suggestion ? `<div class="afi-result-suggestion">💡 ${r.analysis.suggestion}</div>` : ''}
        <div class="afi-result-actions">
          <button class="afi-action-btn afi-justification-btn" data-index="${i}" title="Why this classification?">📋 Justification</button>
          <button class="afi-action-btn afi-playwright-btn" data-index="${i}" title="Generate Playwright MCP prompt to replay">🎭 Replay Prompt</button>
          <button class="afi-action-btn afi-deep-analyze" title="Check Case History & Past Results">🔬 Deep Analyze</button>
          <button class="afi-action-btn afi-view-history" title="Open Case History menu">📜 History</button>
          ${r.domLink ? `<a class="afi-action-btn" href="${r.domLink}" target="_blank" title="View ReConstructed DOM">🖼️ DOM</a>` : ''}
          ${r.failureVideoLink ? `<a class="afi-action-btn" href="${r.failureVideoLink}" target="_blank" title="View Failure Video for verification">🎬 Video</a>` : ''}
        </div>
      </div>
    `;
  }

  // ============================================
  // FULL REPORT IN NEW TAB
  // ============================================

  function openFullReport(results) {
    const reportHtml = generateFullReportHtml(results);
    const blob = new Blob([reportHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  }

  function generateFullReportHtml(results) {
    const counts = { PRODUCT_ISSUE: 0, AUTOMATION_ISSUE: 0, NEEDS_REVIEW: 0 };
    results.forEach(r => counts[r.analysis.verdict]++);
    
    const sourceUrl = window.location.href;
    const reportDate = new Date().toLocaleString();
    const resultsJson = JSON.stringify(results.map(r => ({
      index: r.index,
      caseName: r.caseName,
      failureText: r.failureText,
      reasonText: r.reasonText,
      verdict: r.analysis.verdict,
      category: r.analysis.category,
      confidence: r.analysis.confidence,
      suggestion: r.analysis.suggestion,
      justification: r.analysis.justification,
      domLink: r.domLink,
      failureVideoLink: r.failureVideoLink,
      idealVideoLink: r.idealVideoLink
    })));

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Failure Intelligence Report - ${new Date().toLocaleDateString()}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: #0d1117;
      color: #e6edf3;
      padding: 20px;
      line-height: 1.5;
    }
    .container { max-width: 1400px; margin: 0 auto; }
    .header {
      background: linear-gradient(135deg, #1a1f35 0%, #141d2e 100%);
      border-radius: 12px;
      padding: 24px;
      margin-bottom: 24px;
    }
    .header h1 { font-size: 28px; margin-bottom: 16px; }
    .stats { display: flex; gap: 24px; flex-wrap: wrap; }
    .stat {
      background: #161b22;
      padding: 16px 24px;
      border-radius: 8px;
      border-left: 4px solid;
    }
    .stat-product { border-color: #ff4444; }
    .stat-automation { border-color: #ffbb33; }
    .stat-review { border-color: #33b5e5; }
    .stat-number { font-size: 32px; font-weight: 700; }
    .stat-label { font-size: 14px; color: #8b949e; }
    .filters { display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; }
    .filter-btn {
      padding: 10px 20px;
      border: 1px solid #30363d;
      background: #21262d;
      color: #e6edf3;
      border-radius: 6px;
      cursor: pointer;
      font-size: 14px;
      transition: all 0.2s;
    }
    .filter-btn:hover, .filter-btn.active { background: #30363d; border-color: #8b949e; }
    .filter-btn.product.active { border-color: #ff4444; background: #ff444422; }
    .filter-btn.automation.active { border-color: #ffbb33; background: #ffbb3322; }
    .filter-btn.review.active { border-color: #33b5e5; background: #33b5e522; }
    .table-container { background: #161b22; border-radius: 12px; overflow: hidden; }
    table { width: 100%; border-collapse: collapse; }
    th {
      background: #21262d;
      padding: 14px 16px;
      text-align: left;
      font-weight: 600;
      font-size: 13px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #8b949e;
      border-bottom: 1px solid #30363d;
    }
    td {
      padding: 14px 16px;
      border-bottom: 1px solid #21262d;
      font-size: 13px;
      vertical-align: top;
    }
    tr:hover { background: #1c2128; }
    .verdict-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 4px 10px;
      border-radius: 4px;
      font-weight: 600;
      font-size: 11px;
    }
    .verdict-product { background: #ff444422; color: #ff6b6b; }
    .verdict-automation { background: #ffbb3322; color: #ffd93d; }
    .verdict-review { background: #33b5e522; color: #33b5e5; }
    .failure-text { max-width: 400px; overflow: hidden; text-overflow: ellipsis; color: #8b949e; }
    .category-tag { background: #30363d; padding: 2px 8px; border-radius: 4px; font-size: 11px; }
    .confidence { color: #8b949e; font-size: 11px; }
    .suggestion { color: #7ee787; font-size: 11px; margin-top: 4px; }
    .row-product { border-left: 3px solid #ff4444; }
    .row-automation { border-left: 3px solid #ffbb33; }
    .row-review { border-left: 3px solid #33b5e5; }
    .export-btns { display: flex; gap: 10px; margin-top: 20px; }
    .export-btn {
      padding: 10px 20px;
      background: #238636;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 14px;
    }
    .export-btn:hover { background: #2ea043; }
    .hidden { display: none !important; }
    .dom-link { color: #58a6ff; text-decoration: none; font-size: 11px; }
    .dom-link:hover { text-decoration: underline; }
    .justification-cell { font-size: 11px; }
    .justification-reason { color: #9ca3af; margin-bottom: 6px; max-height: 60px; overflow: hidden; text-overflow: ellipsis; }
    .view-full-btn, .replay-btn {
      background: #21262d;
      border: 1px solid #30363d;
      color: #58a6ff;
      padding: 4px 8px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 10px;
    }
    .view-full-btn:hover, .replay-btn:hover { background: #30363d; }
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.85);
      z-index: 10000;
      display: flex;
      align-items: center;
      justify-content: center;
      backdrop-filter: blur(4px);
    }
    .modal-content {
      background: #1a1f35;
      border-radius: 12px;
      padding: 24px;
      max-width: 800px;
      width: 90%;
      max-height: 85vh;
      overflow-y: auto;
      border: 2px solid #8b5cf6;
    }
    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      border-bottom: 1px solid #333;
      padding-bottom: 12px;
    }
    .modal-close {
      background: #333;
      border: none;
      color: #fff;
      width: 32px;
      height: 32px;
      border-radius: 50%;
      cursor: pointer;
      font-size: 18px;
    }
    .copy-btn {
      background: #22c55e;
      border: none;
      color: #fff;
      padding: 8px 16px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 13px;
    }
    .prompt-box {
      background: #161b22;
      padding: 16px;
      border-radius: 6px;
      font-family: monospace;
      font-size: 12px;
      white-space: pre-wrap;
      word-break: break-word;
      max-height: 400px;
      overflow-y: auto;
      line-height: 1.6;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🔍 Failure Intelligence Report</h1>
      <p style="color: #8b949e; margin-bottom: 16px;">
        Generated: ${reportDate}<br>
        Source: <a href="${sourceUrl}" style="color: #58a6ff;">${sourceUrl.substring(0, 80)}...</a>
      </p>
      <div class="stats">
        <div class="stat stat-product">
          <div class="stat-number">${counts.PRODUCT_ISSUE}</div>
          <div class="stat-label">🔴 Product Issues</div>
        </div>
        <div class="stat stat-automation">
          <div class="stat-number">${counts.AUTOMATION_ISSUE}</div>
          <div class="stat-label">🟡 Automation Issues</div>
        </div>
        <div class="stat stat-review">
          <div class="stat-number">${counts.NEEDS_REVIEW}</div>
          <div class="stat-label">🔵 Needs Review</div>
        </div>
        <div class="stat" style="border-color: #8b949e;">
          <div class="stat-number">${results.length}</div>
          <div class="stat-label">📊 Total Failures</div>
        </div>
      </div>
    </div>

    <div class="filters">
      <button class="filter-btn active" data-filter="all">All (${results.length})</button>
      <button class="filter-btn product" data-filter="PRODUCT_ISSUE">🔴 Product (${counts.PRODUCT_ISSUE})</button>
      <button class="filter-btn automation" data-filter="AUTOMATION_ISSUE">🟡 Automation (${counts.AUTOMATION_ISSUE})</button>
      <button class="filter-btn review" data-filter="NEEDS_REVIEW">🔵 Review (${counts.NEEDS_REVIEW})</button>
    </div>

    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Test Case</th>
            <th>Verdict</th>
            <th>Category</th>
            <th>Failure Details</th>
            <th>Conf.</th>
            <th>Justification</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="results-body">
          ${results.map((r, i) => {
            const justification = r.analysis.justification || {};
            return `
            <tr class="result-row row-${r.analysis.verdict.toLowerCase().replace('_', '-')}" data-verdict="${r.analysis.verdict}" data-index="${i}">
              <td>${i + 1}</td>
              <td><strong>${escapeHtml(r.caseName)}</strong></td>
              <td>
                <span class="verdict-badge verdict-${r.analysis.verdict.toLowerCase().replace('_', '-')}">
                  ${getVerdictEmoji(r.analysis.verdict)} ${getVerdictLabel(r.analysis.verdict)}
                </span>
              </td>
              <td><span class="category-tag">${r.analysis.category}</span></td>
              <td>
                <div class="failure-text">${escapeHtml((r.failureText || r.reasonText || 'N/A').substring(0, 200))}</div>
                ${r.analysis.suggestion ? `<div class="suggestion">💡 ${r.analysis.suggestion}</div>` : ''}
              </td>
              <td><span class="confidence">${r.analysis.confidence}%</span></td>
              <td>
                <div class="justification-cell">
                  <div class="justification-reason">${escapeHtml(justification.reason || r.analysis.suggestion || 'Pattern matched')}</div>
                  <button class="view-full-btn" onclick="showFullJustification(${i})">📋 View Full</button>
                </div>
              </td>
              <td>
                <div style="display:flex;gap:6px;flex-wrap:wrap;">
                  ${r.domLink ? `<a class="dom-link" href="${r.domLink}" target="_blank" title="View DOM">🖼️</a>` : ''}
                  ${r.failureVideoLink ? `<a class="dom-link" href="${r.failureVideoLink}" target="_blank" title="View Video">🎬</a>` : ''}
                  <button class="replay-btn" onclick="showPlaywrightPrompt(${i})" title="Generate Playwright MCP Prompt">🎭</button>
                </div>
              </td>
            </tr>
          `;}).join('')}
        </tbody>
      </table>
    </div>

    <div class="export-btns">
      <button class="export-btn" onclick="exportCSV()">📥 Export CSV</button>
      <button class="export-btn" onclick="window.print()">🖨️ Print Report</button>
    </div>
  </div>

  <script>
    const resultsData = ${resultsJson};
    
    document.querySelectorAll('.filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        const filter = btn.dataset.filter;
        document.querySelectorAll('.result-row').forEach(row => {
          if (filter === 'all' || row.dataset.verdict === filter) {
            row.classList.remove('hidden');
          } else {
            row.classList.add('hidden');
          }
        });
      });
    });

    function exportCSV() {
      const rows = [['#', 'Test Case', 'Verdict', 'Category', 'Failure', 'Reason', 'Confidence', 'Justification', 'DOM Link', 'Video Link']];
      resultsData.forEach((r, i) => {
        rows.push([
          i + 1, 
          r.caseName, 
          r.verdict, 
          r.category, 
          (r.failureText || '').replace(/,/g, ';').replace(/\\n/g, ' ').substring(0, 200),
          (r.reasonText || '').replace(/,/g, ';').replace(/\\n/g, ' ').substring(0, 200),
          r.confidence + '%',
          r.justification?.reason || r.suggestion || 'Pattern matched',
          r.domLink || '',
          r.failureVideoLink || ''
        ]);
      });
      const csvContent = rows.map(row => row.map(cell => '"' + String(cell).replace(/"/g, '""') + '"').join(',')).join('\\n');
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'failure-intelligence-report-${new Date().toISOString().split('T')[0]}.csv';
      a.click();
    }

    function showFullJustification(index) {
      const r = resultsData[index];
      const j = r.justification || {};
      const verdictColor = r.verdict === 'PRODUCT_ISSUE' ? '#f85149' : r.verdict === 'AUTOMATION_ISSUE' ? '#d29922' : '#58a6ff';
      const verdictLabel = r.verdict === 'PRODUCT_ISSUE' ? 'Product Issue' : r.verdict === 'AUTOMATION_ISSUE' ? 'Automation Issue' : 'Needs Review';
      
      const modal = document.createElement('div');
      modal.className = 'modal-overlay';
      modal.innerHTML = \`
        <div class="modal-content" style="border-color: \${verdictColor};">
          <div class="modal-header">
            <h2 style="margin:0;color:#fff;font-size:18px;">📋 Classification Justification</h2>
            <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
          </div>
          <div style="margin-bottom:16px;">
            <div style="color:#888;font-size:11px;text-transform:uppercase;margin-bottom:4px;">Test Case</div>
            <div style="color:#e6edf3;font-size:14px;">#\${index + 1} \${r.caseName}</div>
          </div>
          <div style="margin-bottom:16px;">
            <div style="color:#888;font-size:11px;text-transform:uppercase;margin-bottom:4px;">Verdict</div>
            <span style="display:inline-block;padding:6px 16px;background:\${verdictColor}22;border:1px solid \${verdictColor};border-radius:20px;color:\${verdictColor};font-weight:600;font-size:14px;">\${verdictLabel}</span>
            <span style="color:#888;font-size:12px;margin-left:12px;">Confidence: \${r.confidence}%</span>
          </div>
          <div style="margin-bottom:16px;background:#161b22;padding:16px;border-radius:8px;border-left:4px solid \${verdictColor};">
            <div style="color:#888;font-size:11px;text-transform:uppercase;margin-bottom:8px;">🎯 Main Reason</div>
            <div style="color:#e6edf3;font-size:14px;line-height:1.6;">\${j.reason || r.suggestion || 'Pattern matched'}</div>
          </div>
          \${j.evidence && j.evidence.length > 0 ? \`
            <div style="margin-bottom:16px;">
              <div style="color:#888;font-size:11px;text-transform:uppercase;margin-bottom:8px;">📊 Evidence</div>
              <ul style="color:#e6edf3;font-size:13px;margin:0;padding-left:20px;line-height:1.8;">
                \${j.evidence.map(e => '<li>' + e + '</li>').join('')}
              </ul>
            </div>
          \` : ''}
          <div style="margin-bottom:16px;background:#0d1117;padding:16px;border-radius:8px;">
            <div style="color:#888;font-size:11px;text-transform:uppercase;margin-bottom:8px;">💡 Why This Classification?</div>
            <div style="color:#9ca3af;font-size:13px;line-height:1.7;">\${j.whyThisVerdict || 'Based on pattern matching against known automation and product issue signatures.'}</div>
          </div>
        </div>
      \`;
      document.body.appendChild(modal);
      modal.addEventListener('click', (e) => { if (e.target === modal) modal.remove(); });
    }

    function showPlaywrightPrompt(index) {
      const r = resultsData[index];
      window._reportRowData = r;
      window._reportRowIndex = index;
      
      const modal = document.createElement('div');
      modal.className = 'modal-overlay';
      modal.innerHTML = \`
        <div class="modal-content" style="max-width:900px;">
          <div class="modal-header">
            <h2 style="margin:0;color:#fff;font-size:18px;">🎭 Run Test with Playwright MCP</h2>
            <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">×</button>
          </div>
          
          <div style="margin-bottom:16px;">
            <div style="color:#888;font-size:11px;text-transform:uppercase;margin-bottom:4px;">Test Case</div>
            <div style="color:#e6edf3;font-size:14px;">#\${index + 1} \${r.caseName}</div>
          </div>
          
          <!-- Account Input Section -->
          <div style="background:#0d1117;padding:16px;border-radius:8px;margin-bottom:16px;border:1px solid #30363d;">
            <div style="color:#fbbf24;font-size:12px;font-weight:600;margin-bottom:12px;">🔐 Account Information (Required)</div>
            <p style="color:#9ca3af;font-size:12px;margin-bottom:12px;">Enter account credentials to run this test:</p>
            
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
              <div>
                <label style="color:#888;font-size:11px;display:block;margin-bottom:4px;">Application URL</label>
                <input type="text" id="report-app-url" placeholder="https://your-app.com" style="width:100%;padding:10px 12px;background:#161b22;border:1px solid #30363d;border-radius:6px;color:#e6edf3;font-size:13px;box-sizing:border-box;">
              </div>
              <div>
                <label style="color:#888;font-size:11px;display:block;margin-bottom:4px;">Username / Email</label>
                <input type="text" id="report-username" placeholder="user@example.com" style="width:100%;padding:10px 12px;background:#161b22;border:1px solid #30363d;border-radius:6px;color:#e6edf3;font-size:13px;box-sizing:border-box;">
              </div>
            </div>
            
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
              <div>
                <label style="color:#888;font-size:11px;display:block;margin-bottom:4px;">Password</label>
                <input type="password" id="report-password" placeholder="••••••••" style="width:100%;padding:10px 12px;background:#161b22;border:1px solid #30363d;border-radius:6px;color:#e6edf3;font-size:13px;box-sizing:border-box;">
              </div>
              <div>
                <label style="color:#888;font-size:11px;display:block;margin-bottom:4px;">Organization (Optional)</label>
                <input type="text" id="report-org" placeholder="company-name" style="width:100%;padding:10px 12px;background:#161b22;border:1px solid #30363d;border-radius:6px;color:#e6edf3;font-size:13px;box-sizing:border-box;">
              </div>
            </div>
            
            <button id="report-generate-btn" style="margin-top:16px;background:#8b5cf6;border:none;color:#fff;padding:10px 20px;border-radius:6px;cursor:pointer;font-size:13px;font-weight:500;width:100%;">🔄 Generate Executable Prompt</button>
          </div>
          
          <!-- Test Reference -->
          <div style="background:#161b22;padding:12px 16px;border-radius:8px;margin-bottom:16px;">
            <div style="color:#888;font-size:11px;text-transform:uppercase;margin-bottom:8px;">📹 Test Reference</div>
            <div style="color:#9ca3af;font-size:12px;line-height:1.6;">
              \${r.idealVideoLink ? '<span style="color:#22c55e;">✅ Ideal Video Available</span> - Prompt will use this to understand correct test flow.<br><a href="' + r.idealVideoLink + '" target="_blank" style="color:#58a6ff;">Watch Ideal Video →</a>' : '<span style="color:#d29922;">⚠️ No Ideal Video</span> - Will use test case description.'}
              \${r.failureVideoLink ? '<br><a href="' + r.failureVideoLink + '" target="_blank" style="color:#f85149;margin-top:4px;display:inline-block;">Watch Failure Video →</a>' : ''}
            </div>
          </div>
          
          <!-- Generated Prompt -->
          <div style="margin-bottom:16px;background:#0d1117;padding:4px;border-radius:8px;">
            <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 12px 8px 12px;">
              <div style="color:#888;font-size:11px;text-transform:uppercase;">📝 Executable Prompt</div>
              <button class="copy-btn" onclick="copyPrompt(this)">📋 Copy</button>
            </div>
            <pre class="prompt-box" id="report-prompt-box" style="max-height:250px;">⬆️ Enter account details above and click "Generate Executable Prompt"</pre>
          </div>
          
          <div style="background:#1e293b;padding:12px 16px;border-radius:8px;">
            <div style="color:#fbbf24;font-size:12px;font-weight:500;margin-bottom:6px;">💡 How to Use</div>
            <ol style="color:#9ca3af;font-size:12px;margin:0;padding-left:20px;line-height:1.8;">
              <li>Enter your test account credentials</li>
              <li>Click "Generate Executable Prompt"</li>
              <li>Copy and paste into VS Code Copilot + Playwright MCP</li>
              <li>Copilot will automatically run the test!</li>
            </ol>
          </div>
        </div>
      \`;
      document.body.appendChild(modal);
      
      // Generate button handler
      document.getElementById('report-generate-btn').addEventListener('click', function() {
        const appUrl = document.getElementById('report-app-url').value.trim();
        const username = document.getElementById('report-username').value.trim();
        const password = document.getElementById('report-password').value.trim();
        const org = document.getElementById('report-org').value.trim();
        
        if (!username) {
          alert('Please enter at least a username/email.');
          return;
        }
        
        const prompt = generatePlaywrightPrompt(window._reportRowData, window._reportRowIndex, {appUrl, username, password, org});
        document.getElementById('report-prompt-box').textContent = prompt;
        
        this.textContent = '✅ Prompt Generated!';
        this.style.background = '#22c55e';
        setTimeout(() => { this.textContent = '🔄 Regenerate Prompt'; this.style.background = '#8b5cf6'; }, 2000);
      });
      
      modal.addEventListener('click', (e) => { if (e.target === modal) modal.remove(); });
    }

    function copyPrompt(btn) {
      const prompt = btn.closest('.modal-content').querySelector('.prompt-box').textContent;
      if (prompt.includes('Enter account details')) {
        alert('Please generate the prompt first.');
        return;
      }
      navigator.clipboard.writeText(prompt).then(() => {
        btn.textContent = '✓ Copied!';
        btn.style.background = '#16a34a';
        setTimeout(() => { btn.textContent = '📋 Copy'; btn.style.background = '#22c55e'; }, 2000);
      });
    }

    function generatePlaywrightPrompt(r, index, account = {}) {
      const caseName = r.caseName || 'Unknown Test Case';
      const failureText = r.failureText || 'No failure text available';
      const reasonText = r.reasonText || '';
      const domLink = r.domLink || '';
      const failureVideoLink = r.failureVideoLink || '';
      const idealVideoLink = r.idealVideoLink || '';
      const verdict = r.verdict || 'UNKNOWN';
      const category = r.category || 'Unknown';
      
      const appUrl = account.appUrl || '[APPLICATION_URL]';
      const username = account.username || '[USERNAME]';
      const password = account.password || '[PASSWORD]';
      const org = account.org || '';
      
      const hasClick = /click|button|submit|select|open|menu/i.test(caseName + failureText);
      const hasInput = /input|fill|type|enter|form|field|text/i.test(caseName + failureText);
      const hasNavigation = /navigate|redirect|page|url|visit/i.test(caseName + failureText);
      const hasValidation = /valid|invalid|error|check|verify/i.test(caseName + failureText);
      
      let prompt = \`EXECUTE THIS TEST CASE USING PLAYWRIGHT MCP:

**Test:** \${caseName}
**Status:** \${verdict === 'PRODUCT_ISSUE' ? '🔴 POTENTIAL BUG' : verdict === 'AUTOMATION_ISSUE' ? '🟡 AUTOMATION ISSUE' : '🟠 NEEDS VERIFICATION'}

---

## STEP 1: LOGIN TO APPLICATION

Navigate to: \${appUrl}
Login with:
- Username: \${username}
- Password: \${password}\${org ? '\\n- Organization: ' + org : ''}

ACTIONS:
1. mcp_playwright_browser_navigate to "\${appUrl}"
2. mcp_playwright_browser_snapshot to find login form
3. mcp_playwright_browser_fill_form with username and password
4. mcp_playwright_browser_click on login/submit button
5. mcp_playwright_browser_wait_for page to load

---

## STEP 2: UNDERSTAND THE TEST STEPS

\`;

      if (idealVideoLink) {
        prompt += \`**IMPORTANT: Watch the IDEAL VIDEO to understand correct test flow:**
\${idealVideoLink}

Replicate the same steps using Playwright MCP.
\`;
      } else {
        prompt += \`**No ideal video. Use test case description:**
Test Case: "\${caseName}"
\`;
      }

      prompt += \`
---

## STEP 3: EXECUTE TEST ACTIONS

Based on "\${caseName}", perform:

\`;

      let stepNum = 1;
      if (hasNavigation) { prompt += stepNum + \`. mcp_playwright_browser_navigate - Go to relevant page\\n\`; stepNum++; }
      prompt += stepNum + \`. mcp_playwright_browser_snapshot - Analyze page\\n\`; stepNum++;
      if (hasClick) { prompt += stepNum + \`. mcp_playwright_browser_click - Click element from test name\\n\`; stepNum++; }
      if (hasInput) { prompt += stepNum + \`. mcp_playwright_browser_fill_form - Enter test data\\n\`; stepNum++; }
      if (hasValidation) { prompt += stepNum + \`. mcp_playwright_browser_snapshot - Check for validation\\n\`; stepNum++; }
      prompt += stepNum + \`. mcp_playwright_browser_take_screenshot - Capture result\\n\`;

      prompt += \`
---

## FAILURE CONTEXT

\\\`\\\`\\\`
\${failureText.substring(0, 350)}\${failureText.length > 350 ? '...' : ''}
\\\`\\\`\\\`
\`;

      if (failureVideoLink) {
        prompt += \`
**Failure Video:** \${failureVideoLink}
\`;
      }

      prompt += \`
---

## STEP 4: VERIFY AND REPORT

After executing:
1. mcp_playwright_browser_take_screenshot
2. Compare with \${idealVideoLink ? 'ideal video' : 'expected behavior'}
3. Report: ✅ Working (automation issue) | ❌ Still failing (product bug) | ⚠️ Different behavior

**AI Classification:** \${verdict === 'PRODUCT_ISSUE' ? '🔴 Product Issue' : verdict === 'AUTOMATION_ISSUE' ? '🟡 Automation Issue' : '🟠 Needs Review'}
**Category:** \${category}\`;

      if (domLink) {
        prompt += \`
**DOM Snapshot:** \${domLink}\`;
      }

      return prompt;
    }
  </script>
</body>
</html>`;
  }

  // ============================================
  // JUSTIFICATION AND PLAYWRIGHT MODALS
  // ============================================

  function showJustificationModal(rowData, index) {
    const analysis = rowData.analysis;
    const justification = analysis.justification || {};
    
    // Remove existing modal if present
    const existingModal = document.getElementById('afi-modal-overlay');
    if (existingModal) existingModal.remove();
    
    const verdictColor = getVerdictColor(analysis.verdict);
    const verdictLabel = getVerdictLabel(analysis.verdict);
    const verdictEmoji = getVerdictEmoji(analysis.verdict);
    
    const modalHtml = `
      <div id="afi-modal-overlay" style="
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.85);
        z-index: 100001;
        display: flex;
        align-items: center;
        justify-content: center;
        backdrop-filter: blur(4px);
      ">
        <div style="
          background: #1a1f35;
          border-radius: 12px;
          padding: 24px;
          max-width: 700px;
          width: 90%;
          max-height: 80vh;
          overflow-y: auto;
          border: 2px solid ${verdictColor};
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
        ">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid #333; padding-bottom: 12px;">
            <h2 style="margin: 0; color: #fff; font-size: 18px;">
              ${verdictEmoji} Classification Justification
            </h2>
            <button id="afi-modal-close" style="
              background: #333;
              border: none;
              color: #fff;
              width: 32px;
              height: 32px;
              border-radius: 50%;
              cursor: pointer;
              font-size: 18px;
            ">×</button>
          </div>
          
          <div style="margin-bottom: 16px;">
            <div style="color: #888; font-size: 11px; text-transform: uppercase; margin-bottom: 4px;">Test Case</div>
            <div style="color: #e6edf3; font-size: 14px;">#${index + 1} ${escapeHtml(rowData.caseName || 'Unknown')}</div>
          </div>
          
          <div style="margin-bottom: 16px;">
            <div style="color: #888; font-size: 11px; text-transform: uppercase; margin-bottom: 4px;">Verdict</div>
            <div style="
              display: inline-block;
              padding: 6px 16px;
              background: ${verdictColor}22;
              border: 1px solid ${verdictColor};
              border-radius: 20px;
              color: ${verdictColor};
              font-weight: 600;
              font-size: 14px;
            ">${verdictLabel}</div>
            <span style="color: #888; font-size: 12px; margin-left: 12px;">Confidence: ${analysis.confidence}%</span>
          </div>
          
          <div style="margin-bottom: 16px;">
            <div style="color: #888; font-size: 11px; text-transform: uppercase; margin-bottom: 4px;">Category</div>
            <div style="color: #e6edf3; font-size: 14px;">${analysis.category}</div>
          </div>
          
          <div style="margin-bottom: 16px; background: #161b22; padding: 16px; border-radius: 8px; border-left: 4px solid ${verdictColor};">
            <div style="color: #888; font-size: 11px; text-transform: uppercase; margin-bottom: 8px;">🎯 Main Reason</div>
            <div style="color: #e6edf3; font-size: 14px; line-height: 1.6;">${justification.reason || analysis.suggestion || 'Pattern matched: ' + (analysis.matchedPattern || 'N/A')}</div>
          </div>
          
          ${justification.evidence && justification.evidence.length > 0 ? `
            <div style="margin-bottom: 16px;">
              <div style="color: #888; font-size: 11px; text-transform: uppercase; margin-bottom: 8px;">📊 Evidence</div>
              <ul style="color: #e6edf3; font-size: 13px; margin: 0; padding-left: 20px; line-height: 1.8;">
                ${justification.evidence.map(e => `<li>${escapeHtml(e)}</li>`).join('')}
              </ul>
            </div>
          ` : ''}
          
          <div style="margin-bottom: 16px; background: #0d1117; padding: 16px; border-radius: 8px;">
            <div style="color: #888; font-size: 11px; text-transform: uppercase; margin-bottom: 8px;">💡 Why This Classification?</div>
            <div style="color: #9ca3af; font-size: 13px; line-height: 1.7;">${escapeHtml(justification.whyThisVerdict || 'Based on pattern matching against known automation and product issue signatures.')}</div>
          </div>
          
          ${analysis.matchedPattern ? `
            <div style="margin-bottom: 16px;">
              <div style="color: #888; font-size: 11px; text-transform: uppercase; margin-bottom: 4px;">🔍 Matched Pattern</div>
              <code style="color: #58a6ff; font-size: 12px; background: #161b22; padding: 8px 12px; border-radius: 4px; display: block; word-break: break-all;">${escapeHtml(analysis.matchedPattern)}</code>
            </div>
          ` : ''}
          
          ${rowData.failureText ? `
            <div style="margin-bottom: 16px;">
              <div style="color: #888; font-size: 11px; text-transform: uppercase; margin-bottom: 4px;">📝 Failure Text (Excerpt)</div>
              <div style="color: #f85149; font-size: 12px; background: #161b22; padding: 12px; border-radius: 4px; font-family: monospace; max-height: 100px; overflow-y: auto;">${escapeHtml(rowData.failureText.substring(0, 300))}${rowData.failureText.length > 300 ? '...' : ''}</div>
            </div>
          ` : ''}
          
          <div style="margin-top: 20px; padding-top: 16px; border-top: 1px solid #333; display: flex; gap: 12px; flex-wrap: wrap;">
            ${rowData.domLink ? `<a href="${rowData.domLink}" target="_blank" style="color: #58a6ff; text-decoration: none; font-size: 13px;">🖼️ View DOM</a>` : ''}
            ${rowData.failureVideoLink ? `<a href="${rowData.failureVideoLink}" target="_blank" style="color: #58a6ff; text-decoration: none; font-size: 13px;">🎬 View Video</a>` : ''}
          </div>
        </div>
      </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    
    // Close handlers
    document.getElementById('afi-modal-close').addEventListener('click', () => {
      document.getElementById('afi-modal-overlay').remove();
    });
    document.getElementById('afi-modal-overlay').addEventListener('click', (e) => {
      if (e.target.id === 'afi-modal-overlay') {
        document.getElementById('afi-modal-overlay').remove();
      }
    });
  }

  function showPlaywrightPromptModal(rowData, index) {
    // Remove existing modal if present
    const existingModal = document.getElementById('afi-modal-overlay');
    if (existingModal) existingModal.remove();
    
    // Store rowData globally for regeneration
    window._currentPlaywrightRowData = rowData;
    window._currentPlaywrightIndex = index;
    
    const modalHtml = `
      <div id="afi-modal-overlay" style="
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.85);
        z-index: 100001;
        display: flex;
        align-items: center;
        justify-content: center;
        backdrop-filter: blur(4px);
      ">
        <div style="
          background: #1a1f35;
          border-radius: 12px;
          padding: 24px;
          max-width: 900px;
          width: 90%;
          max-height: 90vh;
          overflow-y: auto;
          border: 2px solid #8b5cf6;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
        ">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid #333; padding-bottom: 12px;">
            <h2 style="margin: 0; color: #fff; font-size: 18px;">
              🎭 Run Test Case with Playwright MCP
            </h2>
            <button id="afi-modal-close" style="
              background: #333;
              border: none;
              color: #fff;
              width: 32px;
              height: 32px;
              border-radius: 50%;
              cursor: pointer;
              font-size: 18px;
            ">×</button>
          </div>
          
          <div style="margin-bottom: 16px;">
            <div style="color: #888; font-size: 11px; text-transform: uppercase; margin-bottom: 4px;">Test Case</div>
            <div style="color: #e6edf3; font-size: 14px;">#${index + 1} ${escapeHtml(rowData.caseName || 'Unknown')}</div>
          </div>
          
          <!-- Account Input Section -->
          <div style="background: #0d1117; padding: 16px; border-radius: 8px; margin-bottom: 16px; border: 1px solid #30363d;">
            <div style="color: #fbbf24; font-size: 12px; font-weight: 600; margin-bottom: 12px;">🔐 Account Information (Required)</div>
            <p style="color: #9ca3af; font-size: 12px; margin-bottom: 12px;">Enter the account credentials to run this test case in Playwright MCP:</p>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px;">
              <div>
                <label style="color: #888; font-size: 11px; display: block; margin-bottom: 4px;">Application URL</label>
                <input type="text" id="afi-app-url" placeholder="https://your-app.com" style="
                  width: 100%;
                  padding: 10px 12px;
                  background: #161b22;
                  border: 1px solid #30363d;
                  border-radius: 6px;
                  color: #e6edf3;
                  font-size: 13px;
                  box-sizing: border-box;
                " value="">
              </div>
              <div>
                <label style="color: #888; font-size: 11px; display: block; margin-bottom: 4px;">Username / Email</label>
                <input type="text" id="afi-username" placeholder="user@example.com" style="
                  width: 100%;
                  padding: 10px 12px;
                  background: #161b22;
                  border: 1px solid #30363d;
                  border-radius: 6px;
                  color: #e6edf3;
                  font-size: 13px;
                  box-sizing: border-box;
                ">
              </div>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
              <div>
                <label style="color: #888; font-size: 11px; display: block; margin-bottom: 4px;">Password</label>
                <input type="password" id="afi-password" placeholder="••••••••" style="
                  width: 100%;
                  padding: 10px 12px;
                  background: #161b22;
                  border: 1px solid #30363d;
                  border-radius: 6px;
                  color: #e6edf3;
                  font-size: 13px;
                  box-sizing: border-box;
                ">
              </div>
              <div>
                <label style="color: #888; font-size: 11px; display: block; margin-bottom: 4px;">Organization/Portal (Optional)</label>
                <input type="text" id="afi-org" placeholder="company-name" style="
                  width: 100%;
                  padding: 10px 12px;
                  background: #161b22;
                  border: 1px solid #30363d;
                  border-radius: 6px;
                  color: #e6edf3;
                  font-size: 13px;
                  box-sizing: border-box;
                ">
              </div>
            </div>
            
            <button id="afi-generate-prompt" style="
              margin-top: 16px;
              background: #8b5cf6;
              border: none;
              color: #fff;
              padding: 10px 20px;
              border-radius: 6px;
              cursor: pointer;
              font-size: 13px;
              font-weight: 500;
              width: 100%;
            ">🔄 Generate Executable Prompt</button>
          </div>
          
          <!-- Test Reference Info -->
          <div style="background: #161b22; padding: 12px 16px; border-radius: 8px; margin-bottom: 16px;">
            <div style="color: #888; font-size: 11px; text-transform: uppercase; margin-bottom: 8px;">📹 Test Reference</div>
            <div style="color: #9ca3af; font-size: 12px; line-height: 1.6;">
              ${rowData.idealVideoLink ? 
                `<span style="color: #22c55e;">✅ Ideal Video Available</span> - The prompt will analyze this video to understand the correct test steps.<br><a href="${rowData.idealVideoLink}" target="_blank" style="color: #58a6ff;">Watch Ideal Video →</a>` : 
                `<span style="color: #d29922;">⚠️ No Ideal Video</span> - The prompt will use the test case description to determine steps.`
              }
              ${rowData.failureVideoLink ? `<br><a href="${rowData.failureVideoLink}" target="_blank" style="color: #f85149; margin-top: 4px; display: inline-block;">Watch Failure Video →</a>` : ''}
            </div>
          </div>
          
          <!-- Generated Prompt -->
          <div style="margin-bottom: 16px; background: #0d1117; padding: 4px; border-radius: 8px;">
            <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 12px 8px 12px;">
              <div style="color: #888; font-size: 11px; text-transform: uppercase;">📝 Executable Prompt for Copilot + Playwright MCP</div>
              <button id="afi-copy-prompt" style="
                background: #22c55e;
                border: none;
                color: #fff;
                padding: 6px 12px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 11px;
                font-weight: 500;
              ">📋 Copy</button>
            </div>
            <pre id="afi-playwright-prompt" style="
              color: #e6edf3;
              font-size: 11px;
              background: #161b22;
              padding: 16px;
              border-radius: 6px;
              font-family: 'Menlo', 'Monaco', 'Courier New', monospace;
              white-space: pre-wrap;
              word-break: break-word;
              margin: 0;
              max-height: 300px;
              overflow-y: auto;
              line-height: 1.5;
            ">⬆️ Enter account details above and click "Generate Executable Prompt"</pre>
          </div>
          
          <div style="background: #1e293b; padding: 12px 16px; border-radius: 8px;">
            <div style="color: #fbbf24; font-size: 12px; font-weight: 500; margin-bottom: 6px;">💡 How to Use</div>
            <ol style="color: #9ca3af; font-size: 12px; margin: 0; padding-left: 20px; line-height: 1.8;">
              <li>Enter your test account credentials above</li>
              <li>Click "Generate Executable Prompt"</li>
              <li>Copy the generated prompt</li>
              <li>Open VS Code with Copilot + Playwright MCP enabled</li>
              <li>Paste the prompt - Copilot will automatically execute the test!</li>
            </ol>
          </div>
        </div>
      </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    
    // Generate prompt handler
    document.getElementById('afi-generate-prompt').addEventListener('click', () => {
      const appUrl = document.getElementById('afi-app-url').value.trim();
      const username = document.getElementById('afi-username').value.trim();
      const password = document.getElementById('afi-password').value.trim();
      const org = document.getElementById('afi-org').value.trim();
      
      if (!username) {
        alert('Please enter at least a username/email to generate the prompt.');
        return;
      }
      
      const accountInfo = { appUrl, username, password, org };
      const prompt = generatePlaywrightMCPPrompt(window._currentPlaywrightRowData, window._currentPlaywrightIndex, accountInfo);
      
      document.getElementById('afi-playwright-prompt').textContent = prompt;
      
      // Highlight that prompt is ready
      const btn = document.getElementById('afi-generate-prompt');
      btn.textContent = '✅ Prompt Generated!';
      btn.style.background = '#22c55e';
      setTimeout(() => {
        btn.textContent = '🔄 Regenerate Prompt';
        btn.style.background = '#8b5cf6';
      }, 2000);
    });
    
    // Copy handler
    document.getElementById('afi-copy-prompt').addEventListener('click', () => {
      const promptText = document.getElementById('afi-playwright-prompt').textContent;
      if (promptText.includes('Enter account details')) {
        alert('Please generate the prompt first by entering account details.');
        return;
      }
      navigator.clipboard.writeText(promptText).then(() => {
        const btn = document.getElementById('afi-copy-prompt');
        btn.textContent = '✓ Copied!';
        btn.style.background = '#16a34a';
        setTimeout(() => {
          btn.textContent = '📋 Copy';
          btn.style.background = '#22c55e';
        }, 2000);
      });
    });
    
    // Close handlers
    document.getElementById('afi-modal-close').addEventListener('click', () => {
      document.getElementById('afi-modal-overlay').remove();
    });
    document.getElementById('afi-modal-overlay').addEventListener('click', (e) => {
      if (e.target.id === 'afi-modal-overlay') {
        document.getElementById('afi-modal-overlay').remove();
      }
    });
  }

  function generatePlaywrightMCPPrompt(rowData, index, accountInfo = {}) {
    const caseName = rowData.caseName || 'Unknown Test Case';
    const failureText = rowData.failureText || 'No failure text available';
    const reasonText = rowData.reasonText || '';
    const domLink = rowData.domLink || '';
    const failureVideoLink = rowData.failureVideoLink || '';
    const idealVideoLink = rowData.idealVideoLink || '';
    const verdict = rowData.analysis?.verdict || 'UNKNOWN';
    const category = rowData.analysis?.category || 'Unknown';
    
    // Account info from user input
    const appUrl = accountInfo.appUrl || '[APPLICATION_URL]';
    const username = accountInfo.username || '[USERNAME]';
    const password = accountInfo.password || '[PASSWORD]';
    const org = accountInfo.org || '';
    
    // Extract useful information from failure text and case name
    const errorMatch = failureText.match(/error[:\s]+([^\n]+)/i);
    const statusMatch = failureText.match(/status[:\s\-]+(\d+)/i);
    const elementMatch = failureText.match(/(locator|selector|element|xpath|css)[:\s]+([^\n]+)/i);
    
    // Parse test case name for action hints
    const caseNameLower = caseName.toLowerCase();
    const hasClick = /click|button|submit|select|open|menu/i.test(caseName + failureText);
    const hasInput = /input|fill|type|enter|form|field|text/i.test(caseName + failureText);
    const hasNavigation = /navigate|redirect|page|url|visit/i.test(caseName + failureText);
    const hasValidation = /valid|invalid|error|check|verify/i.test(caseName + failureText);
    
    // Build action-oriented executable prompt
    let prompt = `EXECUTE THIS TEST CASE USING PLAYWRIGHT MCP:

**Test:** ${caseName}
**Current Status:** ${verdict === 'PRODUCT_ISSUE' ? '🔴 POTENTIAL BUG' : verdict === 'AUTOMATION_ISSUE' ? '🟡 AUTOMATION ISSUE' : '🟠 NEEDS VERIFICATION'}

---

## STEP 1: LOGIN TO APPLICATION

Navigate to: ${appUrl}
Login with:
- Username: ${username}
- Password: ${password}${org ? `\n- Organization: ${org}` : ''}

ACTIONS:
1. mcp_playwright_browser_navigate to "${appUrl}"
2. mcp_playwright_browser_snapshot to find login form
3. mcp_playwright_browser_fill_form with username "${username}" and password "${password}"
4. mcp_playwright_browser_click on login/submit button
5. mcp_playwright_browser_wait_for page to load after login

---

## STEP 2: UNDERSTAND THE TEST STEPS

`;

    // Reference ideal video if available, otherwise use test description
    if (idealVideoLink) {
      prompt += `**IMPORTANT: Watch the IDEAL VIDEO to understand the correct test flow:**
${idealVideoLink}

The ideal video shows exactly how this test SHOULD work. Watch it and replicate the same steps using Playwright MCP.

After watching, perform the same actions you see in the video:
`;
    } else {
      prompt += `**No ideal video available. Use test case description to determine steps:**

Test Case: "${caseName}"

Based on this test name, perform these likely actions:
`;
    }

    // Generate action steps based on case name and failure context
    prompt += `
---

## STEP 3: EXECUTE TEST ACTIONS

Based on the test case "${caseName}", perform these actions:

`;

    let stepNum = 1;
    
    if (hasNavigation) {
      prompt += `${stepNum}. mcp_playwright_browser_navigate - Go to the relevant page/section mentioned in test name\n`;
      stepNum++;
    }
    
    prompt += `${stepNum}. mcp_playwright_browser_snapshot - Analyze the page structure\n`;
    stepNum++;
    
    if (hasClick) {
      prompt += `${stepNum}. mcp_playwright_browser_click - Click on the element/button mentioned in "${caseName}"\n`;
      stepNum++;
    }
    
    if (hasInput) {
      prompt += `${stepNum}. mcp_playwright_browser_fill_form - Enter test data in the relevant fields\n`;
      stepNum++;
    }
    
    if (hasValidation) {
      prompt += `${stepNum}. mcp_playwright_browser_snapshot - Check for validation messages or errors\n`;
      stepNum++;
    }
    
    prompt += `${stepNum}. mcp_playwright_browser_take_screenshot - Capture the result\n`;

    // Add failure context
    prompt += `
---

## FAILURE CONTEXT (What went wrong in automation)

\`\`\`
${failureText.substring(0, 400)}${failureText.length > 400 ? '...' : ''}
\`\`\`
`;

    if (reasonText) {
      prompt += `
**Failure Reason:** ${reasonText.substring(0, 200)}${reasonText.length > 200 ? '...' : ''}
`;
    }

    // Add failure video for comparison
    if (failureVideoLink) {
      prompt += `
**Failure Video (shows what went wrong):** ${failureVideoLink}
`;
    }

    // Verification instructions
    prompt += `
---

## STEP 4: VERIFY AND REPORT

After executing the test:
1. mcp_playwright_browser_take_screenshot - Capture final state
2. Compare with ${idealVideoLink ? 'the ideal video behavior' : 'expected behavior based on test name'}
3. Report whether this is:
   - ✅ Working correctly (automation issue - test needs fix)
   - ❌ Still failing (product bug - needs developer attention)
   - ⚠️ Different behavior than expected

---

**Classification from AI Analysis:** ${verdict === 'PRODUCT_ISSUE' ? '🔴 Product Issue - Likely a real bug' : verdict === 'AUTOMATION_ISSUE' ? '🟡 Automation Issue - Likely test problem' : '🟠 Needs Review - Manual verification needed'}

**Category:** ${category}
`;

    // Add DOM link if available
    if (domLink) {
      prompt += `
**DOM Snapshot (page state at failure):** ${domLink}
`;
    }

    return prompt;
  }

  // ============================================
  // DEEP ANALYSIS WITH CASE HISTORY
  // ============================================

  function openCaseHistory(rowData) {
    const row = document.getElementById(rowData.rowId) || rowData.element;
    if (!row) {
      alert('Row element not found');
      return;
    }

    // Find Case History menu item
    const menuItems = row.querySelectorAll('li');
    let caseHistoryItem = null;
    
    menuItems.forEach(item => {
      if (item.innerText.trim().includes('Case History')) {
        caseHistoryItem = item;
      }
    });

    if (caseHistoryItem) {
      // Trigger mouseenter to show submenu
      caseHistoryItem.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
      caseHistoryItem.click();
      
      // Highlight the row
      row.style.outline = '3px solid #4CAF50';
      row.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setTimeout(() => row.style.outline = '', 5000);
    } else {
      alert('Case History menu not found. Please expand the row first by clicking on it, then try again.');
    }
  }

  async function performDeepAnalysis(rowData, index) {
    const resultEl = document.getElementById(`afi-row-${index}`);
    const btn = resultEl?.querySelector('.afi-deep-analyze');
    
    if (btn) {
      btn.textContent = '⏳ Analyzing...';
      btn.disabled = true;
    }

    try {
      const row = document.getElementById(rowData.rowId) || rowData.element;
      if (!row) {
        throw new Error('Row element not found');
      }

      // Scroll to row
      row.scrollIntoView({ behavior: 'smooth', block: 'center' });
      row.style.outline = '3px solid #4CAF50';
      await sleep(500);

      // Find Case History menu
      const menuItems = row.querySelectorAll('li');
      let caseHistoryItem = null;
      
      menuItems.forEach(item => {
        if (item.innerText.trim().includes('Case History')) {
          caseHistoryItem = item;
        }
      });

      if (!caseHistoryItem) {
        throw new Error('Case History menu not found. Click on the row to expand it first.');
      }

      // Hover to show submenu
      caseHistoryItem.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
      await sleep(400);

      // Find submenu items
      const submenuItems = row.querySelectorAll('ul li');
      let inThisReportLink = null;
      let pastFinalLink = null;

      submenuItems.forEach(item => {
        const text = item.innerText.toLowerCase().trim();
        if (text.includes('in this report')) {
          const anchor = item.querySelector('a');
          if (anchor) inThisReportLink = anchor.href;
        }
        if (text.includes('past final result')) {
          pastFinalLink = item;
        }
      });

      // Build analysis result
      let analysisHtml = '<div class="afi-deep-result">';
      analysisHtml += '<strong>🔬 Deep Analysis Result:</strong><br><br>';
      
      if (inThisReportLink) {
        analysisHtml += `✅ <a href="${inThisReportLink}" target="_blank" style="color:#58a6ff">In This Report</a> - Check if 1st run passed, 2nd failed<br>`;
      } else {
        analysisHtml += '⚠️ "In This Report" link not found<br>';
      }

      if (pastFinalLink) {
        analysisHtml += '✅ Past Final Results available - Click to compare history<br>';
        // Click to open past final results
        pastFinalLink.click();
        analysisHtml += '<br>📂 <em>Opening Past Final Results in new tab...</em><br>';
        analysisHtml += '<br><strong>📋 Analysis Guide:</strong><br>';
        analysisHtml += '1. Check if same failure occurred before<br>';
        analysisHtml += '2. If previously marked as Product Issue → Likely Product<br>';
        analysisHtml += '3. If first run passes, second fails → Likely Automation (flaky)<br>';
        analysisHtml += '4. If failure is intermittent → Automation Issue';
      } else {
        analysisHtml += '⚠️ "Past Final Results" not found<br>';
      }

      analysisHtml += '</div>';

      // Add result to the card
      const existingDeep = resultEl.querySelector('.afi-deep-result');
      if (existingDeep) existingDeep.remove();
      resultEl.insertAdjacentHTML('beforeend', analysisHtml);

      // Reset outline after delay
      setTimeout(() => row.style.outline = '', 5000);

    } catch (error) {
      console.error('Deep analysis error:', error);
      alert('Deep Analysis Error:\n' + error.message + '\n\nTip: Make sure the row is expanded to see the Case History menu.');
    } finally {
      if (btn) {
        btn.textContent = '🔬 Deep Analyze';
        btn.disabled = false;
      }
    }
  }

  // ============================================
  // MAIN EXECUTION
  // ============================================

  function init() {
    console.log("🔍 Analyzing page for automation failures...");
    
    setTimeout(() => {
      const results = analyzeAllFailures();
      console.log(`📊 Analysis complete: ${results.length} failures found`);
      createPanel(results);
    }, 2000);
  }

  // Run on page load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Expose API for external use
  window.AFI = {
    analyze: analyzeAllFailures,
    getResults: () => window.AFI_RESULTS || analyzeAllFailures(),
    openFullReport: () => openFullReport(window.AFI_RESULTS || analyzeAllFailures()),
    refresh: init,
    deepAnalyze: performDeepAnalysis
  };

})();
